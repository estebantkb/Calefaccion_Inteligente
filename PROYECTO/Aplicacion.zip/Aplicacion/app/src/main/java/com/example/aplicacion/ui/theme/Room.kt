package com.example.aplicacion.ui.theme

data class Room(val id: Int, var isHeatingOn: Boolean, var configuredTemperature: Int)