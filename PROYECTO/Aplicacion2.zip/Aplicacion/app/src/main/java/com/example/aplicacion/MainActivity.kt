package com.example.aplicacion

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    private lateinit var spinnerRooms: Spinner
    private lateinit var seekBarTemperature: SeekBar
    private lateinit var btnToggle: Button
    private lateinit var textViewTemperature: TextView
    private lateinit var adapter: ArrayAdapter<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Inicializa las salas (puedes ajustar el número según tus necesidades)
        RoomManager.initializeRooms(10)

        // Inicializa los elementos de la interfaz
        spinnerRooms = findViewById(R.id.spinnerRooms)
        seekBarTemperature = findViewById(R.id.seekBarTemperature)
        btnToggle = findViewById(R.id.btnToggle)
        textViewTemperature = findViewById(R.id.textViewTemperature)

        // Inicializa roomNames y adapter con los nombres de las salas
        val initialRoomNames = updateRoomNames()
        adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, initialRoomNames)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerRooms.adapter = adapter

        // Configura el listener del SeekBar para actualizar el TextView
        seekBarTemperature.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                // Actualiza el TextView con la temperatura seleccionada
                val temperatureText = "Temperatura: $progress°C"
                textViewTemperature.text = temperatureText

                // Actualiza el texto en el Spinner para mostrar la temperatura configurada
                val selectedRoom = spinnerRooms.selectedItemPosition
                val roomText = "Sala ${selectedRoom + 1} / $progress°C / ${getStateText(RoomManager.getHeatingStatus(selectedRoom + 1))}"
                adapter.remove(adapter.getItem(selectedRoom))
                adapter.insert(roomText, selectedRoom)

                // Actualiza la temperatura en la sala seleccionada
                RoomManager.updateTemperature(selectedRoom + 1, progress)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                // No se necesita implementar en este caso
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                // No se necesita implementar en este caso
            }
        })

        // Configura el listener del botón de encender/apagar la calefacción
        btnToggle.setOnClickListener {
            val selectedRoom = spinnerRooms.selectedItemPosition + 1

            // Utiliza el método de RoomManager para encender o apagar la calefacción
            RoomManager.toggleHeating(selectedRoom)

            // Actualiza el texto en el Spinner para mostrar el estado de la calefacción
            val updatedRoomNames = updateRoomNames()
            adapter.clear()
            adapter.addAll(updatedRoomNames)
            adapter.notifyDataSetChanged()
        }
    }

    // Método auxiliar para obtener el texto del estado de la calefacción
    private fun getStateText(isHeatingOn: Boolean?): String {
        return if (isHeatingOn == true) "Encendido" else "Apagado"
    }

    // Método auxiliar para actualizar los nombres de las salas con el estado de la calefacción y la temperatura
    private fun updateRoomNames(): List<String> {
        return RoomManager.rooms.mapIndexed { index, room ->
            val roomTemperature = room.configuredTemperature
            val heatingStatus = getStateText(room.isHeatingOn)
            "Sala ${index + 1} / $roomTemperature°C / $heatingStatus"
        }
    }
}


