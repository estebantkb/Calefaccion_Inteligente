package com.example.aplicacion

object RoomManager {
    val rooms = mutableListOf<Room>()

    fun initializeRooms(numRooms: Int) {
        for (i in 1..numRooms) {
            rooms.add(Room(i, false, 20))
        }
    }


    fun toggleHeating(roomId: Int) {
        rooms.find { it.id == roomId }?.apply {
            isHeatingOn = !isHeatingOn
        }
    }

    fun controlTemperature(roomId: Int, temperature: Int) {
        rooms.find { it.id == roomId }?.apply {
            isHeatingOn = true
            configuredTemperature = temperature
        }
    }

    fun updateTemperature(roomId: Int, temperature: Int) {
        rooms.find { it.id == roomId }?.apply {
            configuredTemperature = temperature
        }
    }

    fun getHeatingStatus(roomId: Int): Boolean {
        return rooms.find { it.id == roomId }?.isHeatingOn ?: false
    }

    fun getConfiguredTemperature(roomId: Int): Int {
        return rooms.find { it.id == roomId }?.configuredTemperature ?: 0
    }
}