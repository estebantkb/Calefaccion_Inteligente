package com.example.aplicacion

data class Room(val id: Int, var isHeatingOn: Boolean, var configuredTemperature: Int)