package com.example.aplicacion

data class Building(val id: Int, val rooms: MutableList<Room>)